package com.example.milestone9;

import android.content.Context;
//import android.content.Intent;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
//import android.view.View;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
//import android.widget.ListAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

public class Activity2 extends MainActivity {

    //data members
    public ListView classListView;
    Button btn_delete, btn_update;
  //  MainActivity mainActivity;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
        Intent intent = getIntent();


        //need to call the database to display the class schedules
       // Class<MainActivity> activityClass = MainActivity.class;
        //DisplayInfo();

        classListView = findViewById(R.id.listView);
        btn_delete = findViewById(R.id.buttonDelete);
        btn_update = findViewById(R.id.updateButton);

        classListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                String text = classListView.getItemAtPosition(i).toString();
                Toast.makeText(Activity2.this," list view"+ text,Toast.LENGTH_SHORT).show();

                db.viewDataList();
            }
        });

        btn_update.setOnClickListener(v -> {

           // MainActivity mainActivity = new MainActivity();
           // mainActivity.delete();
            Context context =getApplicationContext();
            String text = "Updated!";
            int duration = Toast.LENGTH_SHORT;
            Toast.makeText(context,text,duration).show();
            db.DeleteData(listItems);

        });

        btn_delete.setOnClickListener(v -> {
            Context context =getApplicationContext();
            String text = "Deleted!";
            int duration = Toast.LENGTH_SHORT;
            Toast.makeText(context,text,duration).show();



        });


    }



   /* public void DisplayInfo(){
       // classListView.setAdapter(ReadDatabase());
       // mainActivity.ReadDatabase(classListView);
    }

   // private ListAdapter ReadDatabase() {
      //  mainActivity.ReadDatabase(classListView);
        return null;
    }
*/


}