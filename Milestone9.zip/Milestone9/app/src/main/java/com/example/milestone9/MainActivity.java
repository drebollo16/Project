package com.example.milestone9;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
//import android.widget.ListView;



public class MainActivity extends AppCompatActivity {


    //data members
    SQLDatabaseHelper db;

    private SQLiteDatabase sqlLiteDB;
    private EditText editText;
    private String Deselected;
    Button btn_add;
    public ListView classListView;
   // StudentInfo studentInfo;

    String listItems;
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new SQLDatabaseHelper(this);

        btn_add = findViewById(R.id.addButton);
        editText = findViewById(R.id.addclassText);
        CalendarView calendarView = findViewById(R.id.calendarView);
        //classListView= findViewById(R.id.listView);

        //viewData();

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            Deselected = year + Integer.toString(month) + dayOfMonth;
          //  ReadDatabase(view);
        });



        //button listeners for add on click
        btn_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String editclassName = editText.getText().toString();
                Context context = getApplicationContext();
                String text = "Added!";
                int duration = Toast.LENGTH_SHORT;
                Toast.makeText(context, text, duration).show();
                // InsertDatabase(editText)

                if (db.insertData(editclassName))
                    if (!editclassName.equals(" ")) {
                        Toast.makeText(MainActivity.this, "Data added", Toast.LENGTH_SHORT).show();
                        //if nothing in the text close connection
                        editText.setText("");
                       // listItems.clear();
                        db.viewDataList();

                        //   delete();
                    } else {
                        Toast.makeText(MainActivity.this, "Data was not added!", Toast.LENGTH_SHORT).show();
                    }

            openActivity2();
            }

        });

    }

    //used with btn add - to open new intent activity reference to btn_update onClick
    private void openActivity2() {
        Intent intent = new Intent(this, Activity2.class);
        startActivity(intent);
       // ReadDatabase(classListView);

        //take the data to show on the listview?
       // ReadDatabase(classListView);
    }


}






