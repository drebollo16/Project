package com.example.milestone9;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;


public class SQLDatabaseHelper extends SQLiteOpenHelper {

    //member variable for DB TABLE
    private static final String CLASS_TABLE = "CLASS_TABLE" ;
    public static final String COLUMN_ID = "ID";
    public static final String COLUMN_CLASS_ID = "CLASS_" + COLUMN_ID;
    public static final String COLUMN_CLASS_NAME = "CLASS_NAME";
    public static final String COLUMN_CLASS_DATE = "CLASS_DATE";

    //create sql statements
    //add the columns for the DB TABLE - class name, Class NUMBER, CLASS DATE
    String createTableStatement = "CREATE TABLE "
            + CLASS_TABLE + " ("
            + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
            + COLUMN_CLASS_ID + " INT, "
            + COLUMN_CLASS_NAME + " STRING, "
            + COLUMN_CLASS_DATE + " DATE)";

    public SQLDatabaseHelper(Context context) {
        //created database call class Database
        super(context, CLASS_TABLE,null,1);
    }



    @Override
    public void onCreate(SQLiteDatabase db) {
        //db comes from parameter
        db.execSQL(createTableStatement);


    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int il) {

        db.execSQL("DROP TABLE IF EXISTS " + CLASS_TABLE);
        onCreate(db);
    }

    //create method to insert data
    public boolean insertData(String editclassName){
        SQLiteDatabase db = this.getReadableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COLUMN_CLASS_NAME, editclassName);
       // contentValues.put(COLUMN_CLASS_ID, classId);

        long result = db.insert(CLASS_TABLE,null,contentValues);

        return result != -1;
    }

    public Cursor viewDataList(){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "Select * FROM " + CLASS_TABLE;
        Cursor cursor = db.rawQuery(query,null);
        return cursor;
    }

    public void DeleteData(String editclassName){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "DELETE FROM" + CLASS_TABLE+ " WHERE" + COLUMN_ID;
        Context context = null;
        context.deleteDatabase(CLASS_TABLE);

    }

    public void UpdateData (String editClassName){
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "UPDATE" + CLASS_TABLE+ " SET" + COLUMN_ID;
        Context context = null;
       // context.update(CLASS_TABLE);
    }

}
