package com.example.milestone9;

public class StudentInfo {

    //data members
    private int className;
    private String name;
    private boolean isActive;
    private int studentId;

    //constructors
    public StudentInfo(int className, String name, boolean isActive, int studentId) {
        this.className = className;
        this.name = name;
        this.isActive = isActive;
        this.studentId = studentId;
    }

    //default constuctor
    public StudentInfo() {
    }

    //getters and setters

    public int getClassName() {
        return className;
    }

    public void setClassName(int className) {
        this.className = className;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public int getStudentId() {
        return studentId;
    }

    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }

    //tostring is for printing contents of a class

    @Override
    public String toString() {
        return "studentInfo{" +
                "className=" + className +
                ", name='" + name + '\'' +
                ", isActive=" + isActive +
                ", studentId=" + studentId +
                '}';
    }
}

